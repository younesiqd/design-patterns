
public class Paypal implements Paiement {

	@Override
	public void payer() {
		System.out.println("paiement avec paypal");
	}

}
