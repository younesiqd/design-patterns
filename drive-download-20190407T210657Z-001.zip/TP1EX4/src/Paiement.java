
public interface Paiement {
	public void payer();

}
