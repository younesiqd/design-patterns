
public class Visa implements Paiement{

	@Override
	public void payer() {
		System.out.println("paiement avec visa");
	}

}
