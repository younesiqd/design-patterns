import java.util.ArrayList;

public class Client {

	public static void main(String[] args) {
		ArrayList<Article> tab=new ArrayList<Article>();
			Article AR=new Article();
			tab.add(AR);
			AR.setArt(new Visa());
			AR.payerArt();
		
			
		
	}

}
