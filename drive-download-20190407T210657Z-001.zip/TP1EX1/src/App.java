
public class App {

	public static void main(String[] args) {
		ClassDoc dc=new ClassDoc();
		dc.setDoc(new DocumentJournal());
		dc.getInfo();
	
	
	
		

	}

}
