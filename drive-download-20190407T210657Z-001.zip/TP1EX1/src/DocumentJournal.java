
public class DocumentJournal implements Document {

	@Override
	public void getInfo() {
		System.out.println("c'est un journal");
		
	}

	public DocumentJournal() {
		super();
		// TODO Auto-generated constructor stub
	}

}
