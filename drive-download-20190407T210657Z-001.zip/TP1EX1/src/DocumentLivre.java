
public  class DocumentLivre implements Document {

	@Override
	public void getInfo() {
		System.out.println("c'est un livre");
		
	}

	public DocumentLivre() {
		super();
		// TODO Auto-generated constructor stub
	}

}
