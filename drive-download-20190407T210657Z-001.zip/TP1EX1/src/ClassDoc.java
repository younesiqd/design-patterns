
public class ClassDoc implements Document {
	protected Document doc;

	@Override
	public void getInfo() {
		doc.getInfo();
		// TODO Auto-generated method stub
		
	}

	public ClassDoc() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Document getDoc() {
		return doc;
	}

	public void setDoc(Document doc) {
		this.doc = doc;
	}

	
	
}
