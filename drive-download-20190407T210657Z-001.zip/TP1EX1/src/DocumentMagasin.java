
public class DocumentMagasin implements Document {

	@Override
	public void getInfo() {
		System.out.println("c'est une magasine");
		
	}

	public DocumentMagasin() {
		super();
		// TODO Auto-generated constructor stub
	}

}
