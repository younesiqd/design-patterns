
public interface Document {
	public void getInfo();

}
